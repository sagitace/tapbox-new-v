<!-- header section strats -->
<header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <span class="d-flex">
              TAPBox
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav  mx-auto ">
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('products')); ?>">Menu</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="<?php echo e(url('show_order')); ?>">Order</a>
              </li>

              <li>
                 <a class="cart_link d-flex" href="<?php echo e(url('show_cart')); ?>">
              <img src="https://img.icons8.com/ios-glyphs/20/FFFFFF/shopping-cart--v1.png" style="margin-top:5px;"/>
              <span style="font-weight:bold; color: white; font-size:12px; "><?php echo e($cart_total); ?></span>
              </a>
              </li>

            <?php if(Route::has('login')): ?>

            <?php if(auth()->guard()->check()): ?>
            <li class="nav-item">
                <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
            </li>
            <?php else: ?>
            <li class="nav-item ml-2">
                <a href="<?php echo e(route('login')); ?>" class="btn btn-primary" id="logincss">
                        Login
                </a>
            </li>
            <li class="nav-item">
                 <a href="<?php echo e(route('register')); ?>" class="btn btn-success">
                        Register
                </a>
            </li>
            <?php endif; ?>
                <?php endif; ?>
            </ul>



          </div>
        </nav>
      </div>
    </header>
    <!-- end header section -->
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox - Copy\tapbox\resources\views/home/header.blade.php ENDPATH**/ ?>