<?php echo e($slot); ?>

<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>