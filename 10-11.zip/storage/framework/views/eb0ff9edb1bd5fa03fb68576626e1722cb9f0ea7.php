<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
  <?php echo $__env->make('admin.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <style>
    .title_deg{
        text-align: center;
        font-size: 25px;
        font-weight: bold;
    }

    .table_deg{
        border: 1px solid white;
        width: 100%;
        margin: auto;
        margin-top: 30px;
        text-align: center;

    }

    .tr_deg{
        background-color: skyblue;
        color: black;
    }

  </style>
  </head>
  <body>
    <div class="container-scroller">
      <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- partial -->
        <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- partial -->


        <div class="main-panel">
          <div class="content-wrapper">

          <h1 class="title_deg">All Orders</h1>

          <div style="display:flex; justify-content:center; align-items:center; padding-bottom:10px; padding-top:10px;">
            <form action="<?php echo e(url('search')); ?>" method="get">
                <?php echo csrf_field(); ?>
                <input type="text" name="search" id="" placeholder="Search product" style="color:black;">
                <input type="submit" name="" id="" value="Search" class="btn btn-outline-primary">
            </form>
          </div>

          <table class="table_deg">
            <tr class="tr_deg">
                <th style="padding:10px;">Name</th>
                <th style="padding:10px;">Email</th>
                <th style="padding:10px;">Address</th>
                <th style="padding:10px;">Phone</th>
                <th style="padding:10px;">Product Name</th>
                <th style="padding:10px;">Quantity</th>
                <th style="padding:10px;">Price</th>
                <th style="padding:10px;">Payment Status</th>
                <th style="padding:10px;">Delivery Status</th>
                <th style="padding:10px;">Image</th>
                <th style="padding:10px;">Delivered</th>
                <th style="padding:10px;">Receipt</th>
                <th style="padding:10px;">Send Email</th>

            </tr>

            <?php $__empty_1 = true; $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

            <tr>

                <td><?php echo e($order->name); ?></td>
                <td><?php echo e($order->email); ?></td>
                <td><?php echo e($order->address); ?></td>
                <td><?php echo e($order->phone); ?></td>
                <td><?php echo e($order->product_title); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td>₱<?php echo e($order->price); ?></td>
                <td><?php echo e($order->payment_status); ?></td>
                <td><?php echo e($order->delivery_status); ?></td>
                <td>
                    <img src="/product/<?php echo e($order->image); ?>" alt="image" height="100px" width="100px">
                </td>
                <td>
                    <?php if($order->delivery_status=='processing'): ?>

                    <a href="<?php echo e(url('delivered',$order->id)); ?>" class="btn btn-primary" onclick="return confirm('Are you sure this product is delivered?')">Delivered</a>

                    <?php elseif($order->delivery_status=='delivered'): ?>

                    <p style="color:green">Delivered</p>

                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(url('print',$order->id)); ?>" class="btn btn-secondary">Print</a>
                </td>

                <td>
                    <a href="<?php echo e(url('send_email',$order->id)); ?>" class="btn btn-info">Send</a>
                </td>

            </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="16" style="padding:10px; font-weight: bold;">
                    No Data Found
                </td>
            </tr>
            <?php endif; ?>

          </table>

          </div>
        </div>


    <!-- container-scroller -->
    <!-- plugins:js -->
   <?php echo $__env->make('admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End custom js for this page -->
  </body>
</html>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox\resources\views/admin/order.blade.php ENDPATH**/ ?>