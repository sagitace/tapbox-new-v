
  <section class="about_section layout_padding">
    <div class="container  ">

      <div class="row">
        <div class="col-md-6 ">
          <div class="img-box">
            <img src="home/images/about-img.png" alt="">
          </div>
        </div>
        <div class="col-md-6">
          <div class="detail-box">
            <div class="heading_container">
              <h2>
                We Are Tapbox
              </h2>
            </div>
            <p>
              Tapbox is an online shopping platform that provides a wide range of products to its customers. We are a team of young and dynamic individuals who are passionate about providing the best products to our customers. We offer snacks, different flavor of milktea, and other products that are of high quality and affordable.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox - Copy\tapbox\resources\views/home/about.blade.php ENDPATH**/ ?>