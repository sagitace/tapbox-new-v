<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h2 style="text-align: center;">Order Details</h2>

    <div style="display: inline;"><h4>Customer Name: </h4><?php echo e($order->name); ?></div>

    <h4>Customer Email: </h4><p><?php echo e($order->email); ?></p>
    <h4>Customer Phone: </h4><p><?php echo e($order->phone); ?></p>
    <h4>Customer Address: </h4><p><?php echo e($order->address); ?></p>

    <h4>Product Name: </h4><p><?php echo e($order->product_title); ?></p>
    <h4>Product Price: </h4><p><?php echo e($order->price); ?></p>
    <h4>Product Quantity: </h4><p><?php echo e($order->quantity); ?></p>
    <h4>Payment Status: </h4><p><?php echo e($order->payment_status); ?></p>
    <h4>Product ID:</h4><p><?php echo e($order->Product_id); ?></p>
    <br>
    <img src="product/<?php echo e($order->image); ?>" height="100px" width="100px">
</body>
</html>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox\resources\views/admin/pdf.blade.php ENDPATH**/ ?>