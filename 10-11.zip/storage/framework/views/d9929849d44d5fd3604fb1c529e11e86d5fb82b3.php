
  <section class="offer_section layout_padding-bottom">
    <div class="offer_container">
      <div class="container ">
        <div class="row">
          <div class="col-md-6  ">
            <div class="box" style="position:relative;">
              <div class="img-box">
                <img src="home/images/white-almond-latte.png" alt="">
              </div>
              <div class="detail-box" >



                <h5>
                  Christmas Sale!
                </h5>
                <h6>
                  Up to <span>20%</span> Off
                </h6>


              </div>
              <img src="<?php echo e(asset('home/images/c2.png')); ?>" class="c2">
            </div>
          </div>
          <div class="col-md-6  ">
            <div class="box " style="position: relative;">
              <div class="img-box">
                <img src="home/images/cheesy-nachos.png" alt="" style="margin-top: -30px;">
              </div>
              <div class="detail-box">
                <h5>
                  Snack Days
                </h5>
                <h6>
                  Up to <span>15%</span> Off
                </h6>

              </div>
              <img src="<?php echo e(asset('home/images/c2.png')); ?>" class="c2">
            </div>
          </div>
          <div class="col-md-6  ">
            <div class="box " style="position: relative;">
              <div class="img-box">
                <img src="home/images/c3.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Free Shipping
                </h5>
                <h6>
                  Order <span>3 items</span> <br>to enjoy 100% free shipping
                </h6>

              </div>
              <img src="<?php echo e(asset('home/images/c2.png')); ?>" class="c2">
            </div>
          </div>
          <div class="col-md-6">
            <div class="box " style="position: relative;">
              <div class="img-box">
                <img src="<?php echo e(asset('home/images/c4.png')); ?>" style="margin-top:10px;" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  New User
                </h5>
                <h6>
                  Get <span>1 item</span> <br>for free on your first order
                </h6>

              </div>
              <img src="<?php echo e(asset('home/images/c2.png')); ?>" class="c2">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox - Copy\tapbox\resources\views/home/offer.blade.php ENDPATH**/ ?>