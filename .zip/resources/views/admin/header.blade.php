
        <!-- partial:partials/_navbar.html -->
        <nav class="navbar p-0 fixed-top d-flex flex-row">

          <div class="navbar-menu-wrapper flex-grow d-flex align-items-stretch">

            <ul class="navbar-nav navbar-nav-right">



            <li>
                <x-app-layout></x-app-layout>
            </li>
          </div>
        </nav>
