
  <section class="offer_section layout_padding-bottom">
    <div class="offer_container">
      <div class="container ">
        <div class="row">
          <div class="col-md-6  ">
            <div class="box ">
              <div class="img-box">
                <img src="home/images/white-almond-latte.png" alt="">
              </div>
              <div class="detail-box">
                <h5>
                  Tasty Thursdays
                </h5>
                <h6>
                  Up to <span>20%</span> Off
                </h6>

              </div>
            </div>
          </div>
          <div class="col-md-6  ">
            <div class="box ">
              <div class="img-box">
                <img src="home/images/cheesy-nachos.png" alt="" style="margin-top: -30px;">
              </div>
              <div class="detail-box">
                <h5>
                  Snack Days
                </h5>
                <h6>
                  Up to <span>15%</span> Off
                </h6>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox\resources\views/home/offer.blade.php ENDPATH**/ ?>