<section class="food_section layout_padding-bottom">

    <div class="container" >
        <div class="heading_container heading_center">
            <h2>Our Menu</h2>

            <br>

            <div>
                <form action="<?php echo e(url('product_search')); ?>" method="GET" style="display: flex;">
                    <input type="text" name="search" placeholder="Search product" style="border-right: none; border:3px solid #ffbe33; border-radius: 5px 0 0 5px;outline: none;width:100%;" class="shs">
                    <button type="submit" class="btn btn-primary" style="color:black; border: 1px solid #ffbe33;background: #ffbe33; color:white; font-weight:bold;border-radius: 0 5px 5px 0;cursor: pointer;font-size: 20px;">Search</button>
                </form>
            </div>

        </div>

      <?php if(session()->has('message')): ?>

        <div class="alert alert-success">

         <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
            <?php echo e(session()->get('message')); ?>


        </div>

        <?php endif; ?>



    <ul class="filters_menu">
        <li class="active" data-filter="*">All</li>

        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li data-filter=".<?php echo e($category->category_name); ?>"><?php echo e($category->category_name); ?></li>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>

      <div class="filters-content">
        <div class="row grid d-flex">

            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="col-sm-6 col-lg-4 all <?php echo e($products->category); ?>">
            <div class="box" style="position: relative;">
            <img src="<?php echo e(asset('home/images/c1.png')); ?>" alt="" style="position: absolute;left: 0;top: 0;display: block;height: 200px;width: 200px;background: url(TRbanner.gif) no-repeat;text-indent: -999em;text-decoration: none; margin-left:-35px;margin-top:-30px;">
              <div>
                <div class="img-box">
                  <img style="height: 170px; width:150px;" src="product/<?php echo e($products->image); ?>" alt="">
                </div>
                <div class="detail-box">
                  <h5>
                    <?php echo e($products->title); ?>

                  </h5>
                  <p>
                  <?php echo e($products->description); ?>

                  </p>
                  <div class="options">

                <?php if($products->discount_price!=null): ?>

                <div style="display:flex;">
                    <h6 style="margin-right:5px; font-weight:bold;">
                        ₱<?php echo e($products->discount_price); ?>

                    </h6>

                    <h6 style="text-decoration: line-through; " class="text-danger">
                        ₱<?php echo e($products->price); ?>

                    </h6>
                </div>

                <?php else: ?>

                    <h6 style="font-weight:bold;">
                        ₱<?php echo e($products->price); ?>

                    </h6>

                <?php endif; ?>

<a href="<?php echo e(url('product_details',$products->id)); ?>" style="margin-right: 5px; font-size:15px; font-weight:bold; padding-left:5px;padding-right:5px;">View</a>
                  </div>
            <div style="margin: 10px 0">
                <h6>Available Quantity: <span style="font-weight: bold;"><?php echo e($products->quantity); ?></span></h6>
            </div>

            <div style="display: flex; justify-content:center; align-items:center; margin-top: 18px; margin-bottom:-10px;">
                <form action="<?php echo e(url('add_cart',$products->id)); ?>" method="POST" style="display:flex;">
                <?php echo csrf_field(); ?>
                <input type="number" name="quantity" value="0" min="1" max="<?php echo e($products->quantity); ?>" style="width: 60px; color:black;border-radius: 5px 0 0 5px; border:yellow;">
                <button type="submit" class="btn btn-success" style="border-radius: 0 5px 5px 0;">Add To Cart</button>
                </form>
            </div>
                </div>

              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

    <span style="margin: 500px;">
            <?php echo $product->withQueryString()->links('pagination::bootstrap-5'); ?>

        </span>
  </section>

<?php /**PATH C:\Users\labin\OneDrive\Desktop\tapbox\tapbox\resources\views/home/product.blade.php ENDPATH**/ ?>