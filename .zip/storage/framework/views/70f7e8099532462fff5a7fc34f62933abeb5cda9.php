
  <section class="client_section layout_padding-bottom">
    <div class="container">
      <div class="heading_container heading_center psudo_white_primary mb_45">
        <h2>
          What Says Our Customers
        </h2>
      </div>
      <div class="carousel-wrap row ">
        <div class="owl-carousel client_owl-carousel">
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <p>
                    As usual super sarap at a very affordable prices gaya ng snacks. Forda pasok din sa taste buds ng matatanda kasi 'di super tamis, naubos ni mama and papa.
                </p>
                <h6>
                  Anonymous
                </h6>
                <p>
                  Tabaco City
                </p>

              </div>
              <div class="img-box">
                <img src="https://img.icons8.com/external-vitaliy-gorbachev-flat-vitaly-gorbachev/500/null/external-hacker-female-profession-vitaliy-gorbachev-flat-vitaly-gorbachev.png" alt="" class="box-img">
              </div>
            </div>
          </div>
          <div class="item">
            <div class="box">
              <div class="detail-box">
                <p>
                  Thank you tapbox! Good for its price. I love the taste of the food. I will definitely order again. The best yung Taro Flavor na milktea tas ung lagi kong inoorder na fries. Love it.
                </p>
                <h6>
                  Anonymous
                </h6>
                <p>
                  Tabaco City
                </p>
              </div>
              <div class="img-box">
                <img  src="https://img.icons8.com/external-vitaliy-gorbachev-lineal-color-vitaly-gorbachev/500/null/external-hacker-male-profession-vitaliy-gorbachev-lineal-color-vitaly-gorbachev.png" alt="" class="box-img">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox - Copy\tapbox\resources\views/home/client.blade.php ENDPATH**/ ?>