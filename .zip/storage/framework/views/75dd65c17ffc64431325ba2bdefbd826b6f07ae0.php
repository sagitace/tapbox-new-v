<!DOCTYPE html>
<html>

<head>
  <!-- Basic -->

  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <!-- Mobile Metas -->
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <!-- Site Metas -->
  <meta name="keywords" content="" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <link rel="shortcut icon" href="<?php echo e(asset('home/images/favicon.png')); ?>" type="">

  <title>TAPBox</title>

  <!-- bootstrap core css -->
  <link rel="stylesheet" type="text/css" href="<?php echo e(asset('home/css/bootstrap.css')); ?>" />

  <!--owl slider stylesheet -->
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css" />
  <!-- nice select  -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/css/nice-select.min.css" integrity="sha512-CruCP+TD3yXzlvvijET8wV5WxxEh5H8P4cmz0RFbKK6FlZ2sYl3AEsKlLPHbniXKSrDdFewhbmBK5skbdsASbQ==" crossorigin="anonymous" />
  <!-- font awesome style -->
  <link href="<?php echo e(asset('home/css/font-awesome.min.css')); ?>" rel="stylesheet" />

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('home/css/style.css')); ?>" rel="stylesheet" />
  <!-- responsive style -->
  <link href="<?php echo e(asset('home/css/responsive.css')); ?>" rel="stylesheet" />

</head>

<body>

<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <div class="hero_area">
    <div class="bg-box">
      <img src="<?php echo e(asset('home/images/crop.jpg')); ?>" alt="" style="height: 80px;">
    </div>
    <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- include header file -->


  <div class="col-sm-6 col-lg-4 all pizza" style="margin:auto; width: 50%; padding:30px;">
            <div class="box">
              <div>
                <div class="img-box" style="padding: 30px;">
                  <img src="/product/<?php echo e($product->image); ?>" alt="" width="250px" height="250px">
                </div>
                <div class="detail-box">
                  <h5>
                    <?php echo e($product->title); ?>

                  </h5>
                  <h6><b>Product Category:</b> <?php echo e($product->category); ?></h6>
                  <p>
                  <b>Product Details: </b><?php echo e($product->description); ?>

                  </p>
                  <div class="options">

                <?php if($product->discount_price!=null): ?>
                    <div style="display: flex;">
                        <h6 style="font-weight:bold;">
                            <b>Price: </b>₱<?php echo e($product->discount_price); ?> &nbsp;
                        </h6>

                        <h6 style="text-decoration: line-through;" class="text-danger">
                             ₱<?php echo e($product->price); ?>

                        </h6>
                    </div>

                <?php else: ?>

                    <h6 style="font-weight:bold;">
                    <b>Price: </b>₱<?php echo e($product->price); ?>

                    </h6>

                <?php endif; ?>


                <h6><b>Available Quantity:</b> <?php echo e($product->quantity); ?></h6>

                <form action="<?php echo e(url('add_cart',$product->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="number" name="quantity" value="0" min="1" style="width: 60px; color:black;">
                <button type="submit" class="btn btn-success text-dark">Add To Cart</button>

                </form>

                  </div>
                </div>
              </div>
            </div>
          </div>
</div>
  <!-- footer section -->
  <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- footer section -->

  <!-- jQery -->
  <script src="home/js/jquery-3.4.1.min.js"></script>
  <!-- popper js -->
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous">
  </script>
  <!-- bootstrap js -->
  <script src="home/js/bootstrap.js"></script>
  <!-- owl slider -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js">
  </script>
  <!-- isotope js -->
  <script src="https://unpkg.com/isotope-layout@3.0.4/dist/isotope.pkgd.min.js"></script>
  <!-- nice select -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-nice-select/1.1.0/js/jquery.nice-select.min.js"></script>
  <!-- custom js -->
  <script src="home/js/custom.js"></script>
  <!-- Google Map -->
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCh39n5U-4IoWpsVGUHWdqB6puEkhRLdmI&callback=myMap">
  </script>
  <!-- End Google Map -->

</body>

</html>
<?php /**PATH C:\Users\labin\OneDrive\Desktop\My Files\Classes\3rd year - first sem\Web Development\tapbox\tapbox\resources\views/home/product_details.blade.php ENDPATH**/ ?>